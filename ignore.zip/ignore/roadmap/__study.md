# Spring

### Roadmap
1. Java Spring Boot: Professional eCommerce Project Masterclass (Faisal Memon) [udemy](https://www.udemy.com/course/spring-boot-using-intellij-build-a-real-world-project) - 47h 
1. Building Microservices with Spring Boot & Spring Cloud (Ramesh Fadatare) [udemy](https://www.udemy.com/course/building-microservices-with-spring-boot-and-spring-cloud) - 33h 
1. Spring Boot Microservices with Spring Cloud, k8s & Docker (Faisal Memon) [udemy](https://www.udemy.com/course/java-spring-boot-microservices-with-spring-cloud-k8s-docker) - 22h 
   

### @Javascript Mastery
https://www.youtube.com/@javascriptmastery/videos

### Spring Boot & Spring Security

1. Master Spring 6, Spring Boot 3, REST, JPA, Hibernate (Eazy Bytes) [udemy](https://www.udemy.com/course/spring-springboot-jpa-hibernate-zero-to-master) - 36h
2. Spring Security 6 Zero to Master along with JWT,OAUTH2 (Eazy Bytes) [udemy](https://www.udemy.com/course/spring-security-zero-to-master) - 24h
3. Building a Java Spring Boot Web App From Scratch (Trevor Page) [udemy](https://www.udemy.com/course/building-a-java-spring-boot-web-app-from-scratch) | 15h
4. Building a RESTful API Application using Spring and Angular (Get Arrays) [udemy](https://www.udemy.com/course/building-a-restful-api-application-using-spring-and-angular) - 11h

### Microservices
1. Master Microservices with SpringBoot,Docker,Kubernetes (Eazy Bytes) [udemy](https://www.udemy.com/course/master-microservices-with-spring-docker-kubernetes) - 39h
2. Building Microservices with Spring Boot & Spring Cloud (Ramesh Fadatare) [udemy](https://www.udemy.com/course/building-microservices-with-spring-boot-and-spring-cloud) - 25h

### Java Advanced: Functionnal Programming
1. todo
### Java Advanced: Multithreading
1. todo

### Java Advanced: Reactive Programming
1. todo

# RUST

### Rust & WASAM

# REACT or Angular



---

- Spring Boot Actuator - Build an Admin Dashboard (Get Arrays) [udemy](https://www.udemy.com/course/springboot-actuator-admin-dashboard) - 6h
- Java Spring Boot E-Commerce Ultimate Course (Nam Ha Minh) [udemy](https://www.udemy.com/course/spring-boot-e-commerce-ultimate) - 85h
- Spring Boot 3, Spring 6 & Hibernate for Beginners (Chad Darby) [udemy](https://www.udemy.com/course/spring-hibernate-tutorial) - 34h
- Learn Advanced Java (John Purcell) [udemy](https://www.udemy.com/course/learn-advanced-java/) - 19h

# Design Pattern & UML
- Master UML - A Complete Unified Modeling Language Guide (Amit Chugh) [udemy](https://www.udemy.com/course/master-uml) | 3 hours
- Design Patterns - Parallel Study:
  - Design Patterns and SOLID Principles with Java (Robert Kohanyi) [packt] | 6h
  - Design Pattern in Java (Dmitri Nesteruk) [udemy](https://www.udemy.com/course/design-patterns-java/) | 10h
  - Design Pattern in Java (Hansen) [Pluralsight] | 9h
    > left at Structural - Decorator
  - Java: SOLID Principles and Top Design Patterns (Piotr Paweska) [udemy](https://www.udemy.com/course/java-solid-principles-and-top-design-patterns) | 5h

# Android

# UI/UX Design
1. Figma 2024: Getting started the Beginner to Pro Class (moonlearning) [udemy](https://www.udemy.com/course/figma-beginner) - 5h