# Roadmap

1. Essential Math for Data Science (2022) [Nield T.]: 350p
1. Master Math by Coding in Python (Codestars) [udemy] - 37h
1. Become an Algebra Master (Krista King) [udemy] - 16h
1. Become a Calculus 1 Master (Krista King) [udemy] - 12h
1. Become a Calculus 2 Master (Krista King) [udemy] - 31h
1. Become a Calculus 3 Master (Krista King) [udemy] - 24h
1. Become a Probability & Statistics Master (Krista King) [udemy] - 15h

# Cursus

1. High School:

   1. Algebra I: Solving linear equations, inequalities, and systems of equations.
   2. Algebra II: Quadratic equations, polynomial functions, exponential and logarithmic functions.
   3. Pre-Calculus: Advanced algebra, trigonometry, and introductory calculus concepts.

2. Advanced:

   1. Statistics: Probability, inferential statistics, data analysis.
   2. Calculus: Limits, derivatives, integrals, and more advanced calculus topics.
