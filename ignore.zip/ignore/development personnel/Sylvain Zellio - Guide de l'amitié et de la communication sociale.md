## Guide de l'amitié et de la communication sociale
###### de Sylvain Zellio

### Avant- Propos
- Si l'homme est la seule espèce capable de parler: c'est dans le but de pouvoir communiquer et de vivre avec ses semblables.
- Le manque de communication sociale est le frein numéro un á l'accès au bonheur.
- L'important n'est pas d'être comme les autres, mais d'apprendre à mieux vivre en harmonie avec les autres en étant soi.
- On ne guérit jamais totalement des troubles de la personnalité, il faut apprendre à vivre avec eux, plutôt que de s'épuiser à les éradiquer.

### Introduction - Quelques Notions Fondamentales