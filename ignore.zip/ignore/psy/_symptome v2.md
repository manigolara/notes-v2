# Amour Propre
- Je suis pas fini.
- Je ne supporte pas me voir dans une glace ou en photo.
- J'ai un sourire de taré.
- Je ne supporte pas le regard des autres sur moi.
- Je provoque le malaise, parfois la pitié.
- J´ai une voix qui irrite.
- j'ai honte d'etre un homme.

# Motivation
- Il faut m'aider, je vais pete un cable.
- Cést dangereux de me laisser tout seul.
- Jái trop la haine.
- J'ai besoin d'aide pour y voir plus clair, pour faire le point.
- J'ai besoin de me faire diagnostiquer, je n'ai jamais suivi de therapie.
- je veux me reconciler avec dieu.

# Situation
- je suis perplexe quel science pourrais m'aidé.
- Je suis seul depuis des années. pas d'amis, pas de relation.
- Sourire me rend mal a l'aise,

# Relation Amoureuse
- Jái peur des relations amoureuses.
- Je ne comprends pas comment je pourrais plaire.

# Medicaments
- Je peux pas me passer des ces medicament: raconter Paris.
- Si je prend pas ces medicament 1 journee, je pete un cable.
- Sans ces medicament, je fini dans un fait divers.

# Mon Pere
- il battait ma mere quand elle etait enceinte
- je ressentait ces remorts d'avoir pas assurer.

# Ma mere
- elle m'en voulait, elle reporter ca haine de mon pere sur moi.
- elle a essayer de ce debarrasser de moi plusieur foi.

# Declencheur
- prise de drogue à mes 18 ans (halucination)
- crise de panique (tranblement, tomber dans les pommes)

# Dangeureux
- Je suis pleind de haine et je n'ai plus personne a decevoir.
---

- il faudrait me voir sans medoc
- je n'aurias jamais du arriver jusqu ici.
- j'ai fait du hors piste
- je peux pas continuer a vivre dans cette misere a me cacher
- si 1 jour je manque des medocs je pete un plomb
- je suis dangereux.
- je part en couille. J'ai la haine.