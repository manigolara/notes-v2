### Pentobarbital Sodique

Barbiturique à action rapide. Ce médicament provoque une sédation profonde suivie d'un coma, puis d'un arrêt cardiaque. Il est administré sous forme liquide, et la personne qui a demandé l'euthanasie doit le boire elle-même dans le cadre d'un processus d'assistance au suicide.

### Association

- [Dignitas](http://www.dignitas.ch/)
- [ADMD](https://www.admd.net/)
- [Pegasos](https://pegasos-association.com/fr/)