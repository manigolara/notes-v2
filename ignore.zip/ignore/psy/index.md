Plusieurs maladies psychiatriques peuvent provoquer un patient à rester isolé chez lui. Voici quelques exemples :

1. **Dépression** : Les personnes souffrant de dépression peuvent éprouver un sentiment écrasant de tristesse, de désespoir et de manque d'énergie, ce qui peut les amener à éviter les interactions sociales et à rester chez elles.

2. **Trouble anxieux** : Les troubles anxieux, tels que l'anxiété sociale ou l'agoraphobie, peuvent rendre les interactions sociales ou le fait de quitter la maison extrêmement stressants, conduisant ainsi à l'isolement.

3. **Trouble obsessionnel-compulsif (TOC)** : Les personnes atteintes de TOC peuvent avoir des obsessions et des compulsions qui rendent difficile de quitter leur domicile.

4. **Schizophrénie** : Les personnes atteintes de schizophrénie peuvent éprouver des symptômes tels que des hallucinations et des délires, ce qui peut les amener à se retirer de la société.

5. **Trouble de la personnalité évitante** : Les individus avec ce trouble ont une peur intense du rejet et de la critique, ce qui les pousse à éviter les interactions sociales et à rester isolés.

6. **Trouble bipolaire** : Pendant les phases dépressives du trouble bipolaire, une personne peut se sentir extrêmement déprimée et isolée.

7. **Phobie sociale (trouble d’anxiété sociale)** : Les personnes souffrant de cette phobie peuvent éviter les situations sociales par peur d'être jugées ou embarrassées.

Chaque individu est unique, et les symptômes peuvent varier considérablement d'une personne à l'autre. Un diagnostic et un traitement appropriés par un professionnel de la santé mentale sont essentiels pour aider les personnes souffrant de ces troubles.