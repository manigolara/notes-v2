
## *Se libérer du connu - Krishnamurti*
- **Chapitre 1**
  - **Le Conditionnement**  
    Chaque individu est façonné par la société, la culture, et l'éducation, ce qui limite la liberté de l'esprit.
  
  - **La Liberté Intérieure**  
    La vraie liberté consiste à voir la réalité sans les filtres du passé, libéré des connaissances accumulées.

  - **La Nature de la Connaissance**  
    La connaissance étant liée au passé, Krishnamurti prône une exploration intérieure sans préjugés pour accéder à une compréhension plus profonde.