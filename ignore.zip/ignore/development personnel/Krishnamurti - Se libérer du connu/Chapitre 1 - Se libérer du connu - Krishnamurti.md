# 

## Chapitre 1 - *Se libérer du connu - Krishnamurti*

### Introduction
- Krishnamurti souligne la nécessité de **se libérer des conditionnements mentaux** et des habitudes culturelles.
- Ces conditionnements **influencent notre perception** du monde et de nous-mêmes.
- Il remet en question les structures établies de pensée et d'**autorité**.

### Le Conditionnement
- **Chaque individu est conditionné** par la société, la culture, la religion et l'éducation.
- Ce conditionnement crée des schémas de pensée rigides qui **restreignent la liberté de l'esprit**.
- Il est essentiel de reconnaître ces conditionnements et de **comprendre leur impact** sur nos actions et réactions.

### La Liberté Intérieure
- La liberté véritable passe par la nécessité de **se libérer de tout ce qui est connu**, c’est-à-dire de l'accumulation de connaissances et d'expériences passées qui entravent une perception immédiate et directe de la réalité.
- Cette liberté réside dans la capacité à **percevoir sans les filtres du passé**.

### La Nature de la Connaissance
- **La connaissance est intrinsèquement liée au passé**, ce qui limite la possibilité de vivre pleinement le moment présent.
- Krishnamurti **invite à une exploration intérieure** sans préjugés et à un questionnement constant pour atteindre une compréhension plus profonde de soi-même et du monde.
    > Cette exploration doit être libérée de tout conditionnement et de toute influence extérieure, afin de permettre une perception directe de la réalité, **non altérée par les connaissances passées**.
    > Ce processus de questionnement et d'observation est crucial pour se libérer des schémas mentaux rigides qui restreignent notre liberté intérieure.

### Conclusion
- Le chapitre se conclut par un **appel à la conscience et à l'observation intérieure pour dépasser les limites imposées par le conditionnement**.
- Il jette ainsi les bases de son enseignement, centré sur **l’importance de l’auto-observation et du questionnement des structures mentales établies**.
