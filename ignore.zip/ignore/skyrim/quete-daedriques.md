02.Un soir au clair de lune		Bague d’Hircine ou Peau du Sauveur	
03.La maison des horreurs (Molag Bal)	Masse de Molag Bal
05.La folie incarnée 			Baton Wabbajack
08.Le seul remède			Bouclier Parasortis
09.La lumière de l'aube			Epée Aubéclat
11.La fin du cauchemar			Crâne de corruption ou amitié avec Erandur
12.La quête de l'extraordinaire		Parchemin des Anciens + Oghma Infinium (+5 à 3 stat au choix)
13.La porte murmurante			Lame d’Ebonite de Mephala
14.Les fragments du passé		Dague de Mehrunes Dagon ou pièces d'or
15.L'appel de Boéthia			Cotte d’ébonite de Boéthia 