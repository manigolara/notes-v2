Le trouble de la personnalité évitante (TPE) est un trouble de la personnalité caractérisé par des comportements de retrait social, un sentiment de honte et une hypersensibilité à la critique. Voici une description détaillée de ce trouble :

### Caractéristiques principales

1. **Évitement des activités sociales et professionnelles** :
    - Les personnes atteintes de TPE évitent les activités qui impliquent des interactions sociales importantes par peur du rejet, de la critique ou de l'humiliation.
    - Elles peuvent refuser des offres d'emploi ou des promotions, ou éviter des situations où elles pourraient être mises en avant ou évaluées.

2. **Sentiment d'infériorité** :
    - Les individus avec TPE ont souvent une faible estime de soi et se perçoivent comme socialement incompétents ou inférieurs aux autres.
    - Ils sont souvent très sensibles aux critiques et rejets, réels ou perçus, et ont tendance à s'isoler pour éviter ces situations douloureuses.

3. **Besoin d'être aimés** :
    - Malgré leur évitement des interactions sociales, les personnes avec TPE désirent souvent être acceptées et aimées.
    - Elles peuvent avoir très peu de relations intimes, car elles craignent d'être rejetées ou blessées.

4. **Hypersensibilité aux critiques** :
    - Elles réagissent de manière intense à toute forme de critique ou de désapprobation, ce qui les pousse encore plus à éviter les situations sociales.

### Critères diagnostiques (selon le DSM-5)

Selon le Manuel diagnostique et statistique des troubles mentaux (DSM-5), le TPE est diagnostiqué sur la base de plusieurs critères. Voici les principaux :

- Évitement des activités professionnelles ou sociales importantes par peur de la critique ou du rejet.
- Réserve dans les relations intimes par peur d'être ridicule ou humilié.
- Réticence à s'impliquer avec les autres à moins d'être certain d'être aimé.
- Préoccupation par la critique ou le rejet dans les situations sociales.
- Inhibition dans les nouvelles situations interpersonnelles par sentiment d'infériorité.
- Répugnance à prendre des risques personnels ou à s'engager dans de nouvelles activités par peur d'embarras.

### Conséquences

Le trouble de la personnalité évitante peut avoir des conséquences significatives sur la vie d'une personne, y compris :

- Isolement social et solitude.
- Difficultés professionnelles en raison de l'évitement des interactions ou des promotions.
- Problèmes relationnels, y compris un nombre limité d'amis proches et de relations intimes.
- Risque accru de dépression et d'autres troubles de l'humeur en raison de l'isolement et du sentiment de rejet.

### Traitement

Le traitement du TPE peut inclure :

1. **Thérapie cognitivo-comportementale (TCC)** :
    - La TCC peut aider les individus à reconnaître et à modifier leurs pensées et comportements négatifs, à développer des compétences sociales et à augmenter leur estime de soi.

2. **Thérapie de groupe** :
    - Les thérapies de groupe peuvent offrir un environnement sûr pour pratiquer les interactions sociales et recevoir du soutien.

3. **Médicaments** :
    - Dans certains cas, des antidépresseurs ou des anxiolytiques peuvent être prescrits pour aider à gérer les symptômes associés à l'anxiété et à la dépression.

4. **Psychoéducation et soutien** :
    - L'éducation sur le trouble et le développement d'un réseau de soutien solide peuvent être bénéfiques.

Un diagnostic et un plan de traitement personnalisés par un professionnel de la santé mentale sont essentiels pour gérer efficacement le trouble de la personnalité évitante.